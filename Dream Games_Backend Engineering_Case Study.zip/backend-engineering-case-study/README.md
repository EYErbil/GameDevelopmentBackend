# Backend Engineering Case Study

Add brief explanation of how you organized your implementation and the choices you made in terms of design while solving problems
