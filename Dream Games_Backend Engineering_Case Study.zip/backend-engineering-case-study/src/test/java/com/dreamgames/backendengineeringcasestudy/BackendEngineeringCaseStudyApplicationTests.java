package com.dreamgames.backendengineeringcasestudy;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class BackendEngineeringCaseStudyApplicationTests {

    @Test
    void contextLoads() {
    }

}
